package ancom.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    EditText user, pwo;
    Button button5, buttonR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        initView();

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

        buttonR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToRegister();
            }
        });
    }

    private void initView() {
        user = findViewById(R.id.user);
        pwo = findViewById(R.id.pwo);
        button5 = findViewById(R.id.button5);
        buttonR = findViewById(R.id.buttonR);
    }

    private void login() {
        String username = user.getText().toString().trim();
        String password = pwo.getText().toString().trim();
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(LoginActivity.this, "请输入用户名和密码", Toast.LENGTH_LONG).show();
        } else {
            // 模拟用户名和密码的验证，这里需要根据实际情况进行修改
            if (isValidUser(username, password)) {
                // 登录成功
                String welcomeMsg = "欢迎您：" + username + "先生";
                Toast.makeText(LoginActivity.this, welcomeMsg, Toast.LENGTH_LONG).show();
            } else {
                // 用户名或密码错误，提示注册
                Toast.makeText(LoginActivity.this, "用户名或密码错误，请注册", Toast.LENGTH_LONG).show();
                // 跳转到注册页面
                navigateToRegister();
            }
        }
    }

    private boolean isValidUser(String username, String password) {
        // 这里可以添加实际的用户名和密码验证逻辑
        return username.equals("admin") && password.equals("123456");
    }

    private void navigateToRegister() {
        Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
        startActivity(intent);
    }
}
